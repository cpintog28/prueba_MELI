import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { AddProductInputDTO, Categoria, Cliente, Color, DeleteProductInputDTO } from '../models/modelMELI';
import { Producto } from '../models/modelMELI';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductoService {

  constructor(private http: HttpClient) { }

  url: string = 'api/Product';

  getAllProducts() {
    return this.http.get<Producto[]>(this.url + '/GetAllProducts');
  }

  getProduct(input) {
    return this.http.get<Producto[]>(this.url + '/GetProduct', input);
  }

  getColors() {
    return this.http.get<Color[]>(this.url + '/GetColors');
  }

  getClientes() {
    return this.http.get<Cliente[]>(this.url + '/GetClientes');
  }

  getCategoria() {
    return this.http.get<Categoria[]>(this.url + '/GetCategorias');
  }

  addProduct(input: AddProductInputDTO) {
    return this.http.post(this.url + '/AddProduct', input);
  }

  deleteProduct(input: DeleteProductInputDTO) {
    return this.http.post(this.url + '/DeleteProduct', input);
  }

}
