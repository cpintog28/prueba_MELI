export interface Producto {
  idProduct: number;
  nombre: string;
  descripcion: string;
  valorUnit: number;
  idColor: number;
  idCliente: number;
  idCategoria: number;
  color: string;
  categoria: string;
  cliente: string;
  imagen: any;
}

export interface Color {  
  nombre: string;
  descripcion: string;
  idColor: number;
}

export interface Cliente {
  idCliente: number;
  nombre: string;
  descripcion: string;
  nit_cc: number;
  celular: number;
}

export interface Categoria {
  nombre: string;
  descripcion: string;
  idCategoria: number;
}

export interface AddProductInputDTO {
  product: Producto;
}

export interface DeleteProductInputDTO {
  idProduct: number;
}
