﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MeliPrueba.Models;
using MeliPrueba.Services;
using MeliPrueba.Models.DTOs.Output;
using MeliPrueba.Models.DTOs.Input;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MeliPrueba.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductController(MyDBContext context)
        {
            _service = new ProductService(context);
        }
      
        [HttpGet]
        public ActionResult<GetAllProductsOutputDTO> GetAllProducts()
        {
            try
            {
                return _service.GetAllProducts();
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        [HttpGet]
        public ActionResult<GetColorsOutputDTO> GetColors()
        {
            try
            {
                return _service.GetColors();
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        [HttpGet]
        public ActionResult<GetClientesOutputDTO> GetClientes()
        {
            try
            {
                return _service.GetClientes();
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        [HttpGet]
        public ActionResult<GetCategoriasOutputDTO> GetCategorias()
        {
            try
            {
                return _service.GetCategorias();
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        [HttpPost]
        public void AddProduct(AddProductInputDTO input)
        {
            try
            {
                _service.AddProduct(input);
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        [HttpPost]
        public void DeleteProduct(DeleteProductInputDTO input)
        {
            try
            {
                _service.DeleteProduct(input);
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        [HttpPost]
        public void GetProduct(GetAllProductsInputDTO input)
        {
            try
            {
                _service.GetProduct(input);
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }


    }
}
