﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MeliPrueba.Models.DTOs.Output;
using MeliPrueba.Models.DTOs.Input;
using MeliPrueba.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using System.Data;

namespace MeliPrueba.Services
{
    public class ProductService : IProductService
    {
        private readonly MyDBContext _contextDB;

        public ProductService(MyDBContext conextDB) {
            _contextDB = conextDB;
        }
        
        public GetAllProductsOutputDTO GetAllProducts()
        {
            try
            {
                GetAllProductsOutputDTO resultado = new GetAllProductsOutputDTO();

                var products = _contextDB.Productos.FromSqlRaw($"meli_GetAllProducts").ToList();

                resultado.producto = products;

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AddProduct(AddProductInputDTO input)
        {
            try
            {
                GetAllProductsOutputDTO result = new GetAllProductsOutputDTO();
                
                var products =  _contextDB.Database.ExecuteSqlRaw($"EXEC meli_AddProduct @nombre, @desc, @valorUnit, @color, @categoria, @cliente, @foto", 
                                                        new SqlParameter("@nombre",input.Product.Nombre), new SqlParameter("@desc", input.Product.Descripcion),
                                                        new SqlParameter("@valorUnit", input.Product.ValorUnit), new SqlParameter("@color", input.Product.IdColor),
                                                        new SqlParameter("@categoria", input.Product.IdCategoria), new SqlParameter("@cliente", input.Product.IdCliente),
                                                        new SqlParameter("@foto", input.Product.Imagen));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }      

        public void DeleteProduct(DeleteProductInputDTO input)
        {
            try
            {
                GetAllProductsOutputDTO result = new GetAllProductsOutputDTO();

                var products = _contextDB.Database.ExecuteSqlRaw($"EXEC meli_DeleteProduct @idProduct", new SqlParameter("@idProduct", input.IdProduct));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public GetColorsOutputDTO GetColors()
        {
            try
            {                
                GetColorsOutputDTO outp = new GetColorsOutputDTO();
                var colors =   _contextDB.Colors.ToList();
                outp.color = colors;
                return outp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public GetClientesOutputDTO GetClientes()
        {
            try
            {
                GetClientesOutputDTO outp = new GetClientesOutputDTO();
                var clientes = _contextDB.Clientes.ToList();
                outp.cliente = clientes;
                return outp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public GetCategoriasOutputDTO GetCategorias()
        {
            try
            {
                GetCategoriasOutputDTO outp = new GetCategoriasOutputDTO();
                var categoria = _contextDB.Categoria.ToList();
                outp.categoria = categoria;
                return outp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public GetAllProductsOutputDTO GetProduct(GetAllProductsInputDTO input)
        {
            try
            {
                GetAllProductsOutputDTO resultado = new GetAllProductsOutputDTO();

                var products = _contextDB.Productos.FromSqlRaw($"meli_GetProduct @IdProduct", new SqlParameter("@IdProduct", input.Product.IdProduct)).ToList();

                resultado.producto = products;

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
    }
}
