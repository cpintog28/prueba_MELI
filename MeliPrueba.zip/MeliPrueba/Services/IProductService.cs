﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MeliPrueba.Models.DTOs.Output;
using MeliPrueba.Models.DTOs.Input;

namespace MeliPrueba.Services
{
    interface IProductService
    {
        GetAllProductsOutputDTO GetProduct(GetAllProductsInputDTO input);
        GetAllProductsOutputDTO GetAllProducts();
        void AddProduct(AddProductInputDTO input);        
        void DeleteProduct(DeleteProductInputDTO input);
        GetColorsOutputDTO GetColors();
        GetClientesOutputDTO GetClientes();
        GetCategoriasOutputDTO GetCategorias();
    }
}
