﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MeliPrueba.Models.DTOs.Input
{
    public class AddProductInputDTO
    {
        public Producto Product { get; set; }
    }
}
