﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MeliPrueba.Models.DTOs.Output
{
    public class GetAllProductsOutputDTO
    {
        public List<Producto> producto { get; set; }
        public Producto product { get; set; }

    }
}
