﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MeliPrueba.Models.DTOs.Output
{
    public class GetColorsOutputDTO
    {
        public List<Color> color { get; set; }
       
    }
}
