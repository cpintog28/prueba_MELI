﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace MeliPrueba.Models
{
    public partial class Producto
    {
        [Key]
        public int IdProduct { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public int? ValorUnit { get; set; }
        public int IdColor { get; set; }
        public int IdCategoria { get; set; }
        public int IdCliente { get; set; }
        public string Imagen { get; set; }
        public virtual Categorium IdCategoriaNavigation { get; set; }
        public virtual Cliente IdClienteNavigation { get; set; }
        public virtual Color IdColorNavigation { get; set; }

        public string Color { get; set; }

        public string Categoria { get; set; }

        public string Cliente { get; set; }
    }
}
