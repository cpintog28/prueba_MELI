﻿using System;
using System.Collections.Generic;

#nullable disable

namespace MeliPrueba.Models
{
    public partial class Color
    {
        public Color()
        {
            Productos = new HashSet<Producto>();
        }

        public int IdColor { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }

        public virtual ICollection<Producto> Productos { get; set; }
    }
}
