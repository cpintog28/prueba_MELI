﻿using System;
using System.Collections.Generic;

#nullable disable

namespace MeliPrueba.Models
{
    public partial class Cliente
    {
        public Cliente()
        {
            Productos = new HashSet<Producto>();
        }

        public int IdCliente { get; set; }
        public int NitCc { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Direccion { get; set; }
        public long? Celular { get; set; }
        public double? Calificacion { get; set; }

        public virtual ICollection<Producto> Productos { get; set; }
    }
}
